package com.example.config;



import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.example.listener.JobListener;
import com.example.model.User;
import com.example.processor.UserItemProcessor;

@Configuration
@EnableBatchProcessing
public class Config {
	@Autowired
	private JobBuilderFactory builderFactory;
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	@Autowired
	private JobListener jobListener;
	@Autowired
	private EntityManagerFactory entityManagerFactory;
	@Autowired
	private UserItemProcessor itemProcessor;
	
	@Bean(name = "reader")
	public FlatFileItemReader<User> createReader(){
		return new FlatFileItemReaderBuilder<User>()
				.name("file-reader")
				.resource(new ClassPathResource("User_Info.csv"))
				.delimited().delimiter(",")
				.names("userId","name","adderess","email")
				.targetType(User.class)
				.build();
	}
	@Bean
	public JpaItemWriter<User> createWriter(){
		return new JpaItemWriterBuilder<User>()
				.entityManagerFactory(entityManagerFactory)
				.build();
	}
	
	@Bean(name = "step1")
	public Step createStep1(){
		return stepBuilderFactory.get("step1")
				.<User,User>chunk(2)
				.reader(createReader())
				.processor(itemProcessor)
				.writer(createWriter())
				.build();
	}
	@Bean(name = "Job1")
	public Job createJob() {
		return builderFactory.get("Job1")
				.listener(jobListener)
				.incrementer(new RunIdIncrementer())
				.start(createStep1())
				.build();
	}

}
