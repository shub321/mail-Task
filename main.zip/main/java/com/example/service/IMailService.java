package com.example.service;

public interface IMailService {
	public String sendmails();

}
