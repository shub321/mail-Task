package com.example.service;

import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.model.User;
import com.example.repo.UserInfoRepo;

public class MailService implements IMailService {
	@Autowired
	private UserInfoRepo repo;

	@Override
	public String sendmails() {
		List<User> list = repo.findAll();
		String host = "smtp.gmail.com";
		String port = "587";
		String password = "your-password";
		String email = "sraikhere@gmail.com";
		String subject = "Subject of the Email";
		String message = "Body of the Email";
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", port);
		props.put("mail.smtp.auth", true);
		props.put("mail.smtp.starttls.enable", "true");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, password);
			}
		});
		try {
			Message emailMessage = new MimeMessage(session);
			emailMessage.setFrom(new InternetAddress(email));
			for (User user : list) {
				emailMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
				emailMessage.setSubject(subject);
				emailMessage.setText("hi");
				Transport.send(emailMessage);
				System.out.println("mail sent");
			}
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
		return null;
	}

}
